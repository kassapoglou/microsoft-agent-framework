﻿using OllamaSharp;
using Microsoft.Agents.AI;
using Microsoft.Extensions.AI;

var uri = new Uri("http://localhost:11434");
var chatClient = new OllamaApiClient(uri, "qwen3:0.6b");

const string instructions = """
You triage customer-support messages for a generic product or service.
Identify the issue type, urgency, customer sentiment, and next best action.
Keep replies concise, practical, and limited to the support domain.
""";

ChatClientAgent triageAgent = chatClient.AsAIAgent(instructions, name: "TriageAgent");
AIAgent agent = triageAgent;

// ===== Single turn =====
AgentResponse singleTurnResponse = await agent.RunAsync(
    "I was charged twice this month and need help before my renewal tomorrow.");

Console.WriteLine("Single turn");
Console.WriteLine(singleTurnResponse.Text);
Console.WriteLine();